package org.apache.log4j.spi;

/**
 * Created by IntelliJ IDEA.
 * User: ceki
 * Date: 19 oct. 2010
 * Time: 11:47:05
 * To change this template use File | Settings | File Templates.
 */
public class LoggingEvent {
}
